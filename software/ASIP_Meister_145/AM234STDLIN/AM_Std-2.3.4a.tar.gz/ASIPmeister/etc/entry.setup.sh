###################################################################
#                                                                 #
#   Copyright 2008 ASIP Solutions, Inc. All rights reserved.      #
#                   Copyright 2002 PEAS Project                   #
#                                                                 #
###################################################################

export ENTRY_HOME=$ASIP_MEISTER_HOME
PATH=$ENTRY_HOME/bin:$PATH
